#!/usr/bin/env bash
# One command: builds the standalone HEXA release APK and installs it on a USB-connected phone.
set -e
cd "$(dirname "$0")"

if [ -z "${JAVA_HOME:-}" ] && [ -x /usr/libexec/java_home ]; then export JAVA_HOME="$(/usr/libexec/java_home -v 17 2>/dev/null || true)"; fi
if [ -z "${ANDROID_HOME:-}" ]; then
  for d in /opt/homebrew/share/android-commandlinetools "$HOME/Library/Android/sdk" "$HOME/Android/Sdk"; do
    [ -d "$d" ] && ANDROID_HOME="$d" && break
  done
fi
[ -n "${ANDROID_HOME:-}" ] || { echo "Set ANDROID_HOME to your Android SDK folder."; exit 1; }
export ANDROID_HOME ANDROID_SDK_ROOT="$ANDROID_HOME"
export PATH="$PATH:$ANDROID_HOME/platform-tools"

npm ci
chmod +x android/gradlew
(cd android && ./gradlew clean assembleRelease)

cp android/app/build/outputs/apk/release/app-release.apk HEXA.apk
echo "Built: $(pwd)/HEXA.apk ($(du -h HEXA.apk | cut -f1))"

if adb get-state >/dev/null 2>&1; then
  adb install -r HEXA.apk || { adb uninstall com.phoneteleop; adb install HEXA.apk; }
  adb shell monkey -p com.phoneteleop -c android.intent.category.LAUNCHER 1 >/dev/null
  echo "Installed and launched on your phone."
else
  echo "No phone detected over USB - share HEXA.apk manually."
fi
