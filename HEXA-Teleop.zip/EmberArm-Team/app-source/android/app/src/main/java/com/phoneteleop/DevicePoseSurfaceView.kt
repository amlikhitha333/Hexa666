package com.phoneteleop

import android.content.Context
import android.graphics.PixelFormat
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.util.Log
import com.google.ar.core.Session
import com.google.ar.core.TrackingState
import com.google.ar.core.exceptions.CameraNotAvailableException
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

class DevicePoseSurfaceView(context: Context, private val poseModule: DevicePoseModule) :
    GLSurfaceView(context), GLSurfaceView.Renderer {

    @Volatile private var arSession: Session? = null
    @Volatile private var displayRotation = 0
    private var surfaceWidth = 1
    private var surfaceHeight = 1
    private var cameraTextureId = 0
    private var textureAssigned = false
    @Volatile private var lastFrameTimestamp = 0L
    @Volatile private var lastTrackingState: String? = null

    init {
        setEGLContextClientVersion(2)
        setEGLConfigChooser(8, 8, 8, 8, 16, 0)
        holder.setFormat(PixelFormat.TRANSLUCENT)
        setZOrderOnTop(true)
        setPreserveEGLContextOnPause(true)
        setRenderer(this)
        renderMode = RENDERMODE_CONTINUOUSLY
        isClickable = false
        isFocusable = false
        setBackgroundColor(android.graphics.Color.TRANSPARENT)
    }

    fun setArSession(session: Session?) {
        arSession = session
        textureAssigned = false
        lastFrameTimestamp = 0L
        lastTrackingState = null
        requestRender()
    }

    fun setDisplayRotation(rotation: Int) {
        displayRotation = rotation
        requestRender()
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(0f, 0f, 0f, 0f)
        val textures = IntArray(1)
        GLES20.glGenTextures(1, textures, 0)
        cameraTextureId = textures[0]
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, cameraTextureId)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        textureAssigned = false
        Log.i(TAG, "OpenGL surface created; camera texture=$cameraTextureId")
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        surfaceWidth = width.coerceAtLeast(1)
        surfaceHeight = height.coerceAtLeast(1)
        GLES20.glViewport(0, 0, surfaceWidth, surfaceHeight)
    }

    override fun onDrawFrame(gl: GL10?) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        val session = arSession ?: return
        if (cameraTextureId == 0) return

        try {
            if (!textureAssigned) {
                session.setCameraTextureName(cameraTextureId)
                textureAssigned = true
                Log.i(TAG, "ARCore camera texture registered on GL thread")
            }

            session.setDisplayGeometry(displayRotation, surfaceWidth, surfaceHeight)
            val frame = session.update()
            val camera = frame.camera
            if (camera.trackingState == TrackingState.TRACKING) {
                lastTrackingState = null
                // This draws at screen refresh (60 Hz) but the camera delivers ~30 frames/s. Only send NEW frames to JS.
                if (frame.timestamp != lastFrameTimestamp) {
                    lastFrameTimestamp = frame.timestamp
                    val pose = camera.pose
                    poseModule.emitPose(pose.translation, pose.rotationQuaternion, "normal")
                }
            } else {
                val state = when (camera.trackingState) {
                    TrackingState.PAUSED -> "initializing"
                    TrackingState.STOPPED -> "unavailable"
                    else -> "initializing"
                }
                if (state != lastTrackingState) { // only on change, not 60 times a second
                    lastTrackingState = state
                    poseModule.emitTrackingState(state)
                }
            }
        } catch (error: CameraNotAvailableException) {
            Log.e(TAG, "ARCore camera unavailable", error)
        } catch (error: Exception) {
            Log.e(TAG, "ARCore frame update failed", error)
        }
    }

    companion object {
        private const val TAG = "DevicePoseGL"
    }
}
