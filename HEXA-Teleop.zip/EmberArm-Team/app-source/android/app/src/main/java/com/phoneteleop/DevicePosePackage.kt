package com.phoneteleop

import com.facebook.react.ReactPackage
import com.facebook.react.bridge.NativeModule
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.uimanager.ViewManager

class DevicePosePackage : ReactPackage {

    @Volatile
    private var poseModule: DevicePoseModule? = null

    private fun getOrCreateModule(
        context: ReactApplicationContext
    ): DevicePoseModule {
        return poseModule ?: synchronized(this) {
            poseModule ?: DevicePoseModule(context).also {
                poseModule = it
            }
        }
    }

    override fun createNativeModules(
        context: ReactApplicationContext
    ): List<NativeModule> {
        return listOf(getOrCreateModule(context))
    }

    override fun createViewManagers(
        context: ReactApplicationContext
    ): List<ViewManager<*, *>> {
        return listOf(
            DevicePoseSurfaceManager(getOrCreateModule(context))
        )
    }
}
