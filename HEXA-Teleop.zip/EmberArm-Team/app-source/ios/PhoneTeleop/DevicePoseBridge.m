#import <React/RCTEventEmitter.h>

@interface RCT_EXTERN_MODULE(DevicePose, RCTEventEmitter)
RCT_EXTERN_METHOD(start:(RCTPromiseResolveBlock)resolve rejecter:(RCTPromiseRejectBlock)reject)
RCT_EXTERN_METHOD(stopTracking)
@end
