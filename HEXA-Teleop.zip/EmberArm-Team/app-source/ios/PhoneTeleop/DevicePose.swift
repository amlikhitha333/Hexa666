import ARKit
import AVFoundation
import React

@objc(DevicePose)
final class DevicePose: RCTEventEmitter, ARSessionDelegate {
  private let session = ARSession()
  private var observing = false
  private var lastTracking = ""
  override init() { super.init(); session.delegate = self }

  @objc(start:rejecter:)
  func start(resolve: RCTPromiseResolveBlock, reject: RCTPromiseRejectBlock) {
    guard ARWorldTrackingConfiguration.isSupported else { reject("AR_UNSUPPORTED", "This device does not support AR world tracking.", nil); return }
    let authorization = AVCaptureDevice.authorizationStatus(for: .video)
    if authorization == .denied || authorization == .restricted {
      reject("CAMERA_DENIED", "Camera access is disabled. Enable Camera for HEXA in Settings.", nil)
      return
    }
    resolve(nil)
    DispatchQueue.main.async { [weak self] in
      guard let self else { return }
      let runSession: (Bool) -> Void = { granted in
        guard granted else {
          self.sendEvent(withName: "deviceTrackingState", body: "unavailable")
          return
        }
        self.session.run(ARWorldTrackingConfiguration(), options: [.resetTracking, .removeExistingAnchors])
        self.lastTracking = ""
        self.observing = true
      }
      if authorization == .notDetermined {
        AVCaptureDevice.requestAccess(for: .video) { granted in
          DispatchQueue.main.async { runSession(granted) }
        }
      } else {
        runSession(true)
      }
    }
  }
  @objc(stopTracking)
  func stopTracking() {
    DispatchQueue.main.async { [weak self] in
      self?.observing = false
      self?.session.pause()
    }
  }
  func session(_ session: ARSession, didUpdate frame: ARFrame) {
    guard observing else { return }
    let transform = frame.camera.transform
    let tracking: String
    switch frame.camera.trackingState {
    case .normal: tracking = "normal"
    case .limited(let reason):
      // Brief "limited" blips (fast motion, blank walls) are common; treating them as lost tracking released the pad and re-anchored the arm.
      switch reason { case .excessiveMotion, .insufficientFeatures: tracking = "normal"; default: tracking = "initializing" }
    case .notAvailable: tracking = "unavailable"
    }
    if tracking != lastTracking { lastTracking = tracking; sendEvent(withName: "deviceTrackingState", body: tracking) }
    let q = simd_quatf(transform)
    sendEvent(withName: "devicePose", body: ["position": ["x": transform.columns.3.x, "y": transform.columns.3.y, "z": transform.columns.3.z], "rotation": ["x": q.imag.x, "y": q.imag.y, "z": q.imag.z, "w": q.real], "tracking": tracking, "timestamp": frame.timestamp * 1000])
  }
  override func supportedEvents() -> [String]! { ["devicePose", "deviceImu", "deviceTrackingState"] }
  override static func requiresMainQueueSetup() -> Bool { true }
}
