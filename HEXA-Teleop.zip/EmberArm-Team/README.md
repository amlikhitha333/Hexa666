# EmberArm: use an Android phone to control a robot arm

Your phone becomes the "leader arm". You hold the phone and move it, and a program on your computer turns that movement into commands for the SO-101 robot arm. You do not need a second (leader) arm.

It has two parts:

1. **The phone app** (`EmberArm-Final.apk`). It tracks how the phone moves, using the camera, and sends that over Wi-Fi.
2. **The server** (the `server` folder). It runs on your computer (Windows or Ubuntu) and moves the arm, or a simulated arm.

Tested with a Samsung Galaxy A35. Any Android phone that supports Google "ARCore" should work. Built and tested on a Mac. The server is the same Python code on Windows and Ubuntu, but we have not run it there yet, so tell us if anything breaks.

---

## What is in this folder

| Name | What it is |
| --- | --- |
| `EmberArm-Final.apk` | The phone app. Install this on the phone. |
| `server/` | The program for your computer. |
| `app-source/` | The phone app's source code. **Ignore this unless you want to change the app.** |

---

## Before you start, you need

- A computer with **Windows 10/11** or **Ubuntu 22.04**, and **Python 3.10 or newer**.
- An Android phone. Samsung A35 works.
- The phone and the computer on the **same Wi-Fi**.
- (Only for the real arm) the SO-101 arm, plugged into the computer by USB, and its power supply.

**Start with the simulation (no arm).** It is safe, and you can check everything works before touching the real arm.

---

## Step 1: Put the app on the phone

1. Copy `EmberArm-Final.apk` to the phone (USB cable, Google Drive, WhatsApp, anything).
2. On the phone, tap the file to install it.
3. If it says "install unknown apps is blocked", tap **Settings** and allow it for the app you opened the file from (Files, Chrome, WhatsApp...), then go back and install.
4. If Google Play Protect warns you, tap **Install anyway**. The app is not from the Play Store, so this warning is normal.
5. Open the app. Allow the **Camera** when it asks. The app needs the camera to track movement.

If the phone says it needs "Google Play Services for AR", tap to install or update it from the Play Store.

---

## Step 2: Start the server on the computer

### Windows

1. Install Python from https://www.python.org/downloads/ . **Tick "Add python.exe to PATH"** on the first screen of the installer.
2. Unzip this folder. Open the `server` folder.
3. Click the address bar of the folder, type `cmd`, and press Enter. A black window opens.
4. Type these two lines (press Enter after each):

```
emberarm.bat setup --no-lerobot
emberarm.bat start --sim
```

The first line installs what the server needs (once only). The second starts the server with a **simulated arm**.

5. If Windows asks about the firewall, tick **Private networks** and click **Allow access**.

### Ubuntu 22.04

Open a terminal in the folder and type:

```bash
sudo apt update
sudo apt install -y python3 python3-venv python3-pip
cd server
chmod +x emberarm.sh
./emberarm.sh setup --no-lerobot
./emberarm.sh start --sim
```

If you run Ubuntu inside a virtual machine (UTM, VirtualBox, VMware), set its network to **Bridged**. Otherwise the phone cannot reach it.

If Ubuntu's firewall is on, run `sudo ufw allow 4443/tcp`.

### What you should see

The server prints a line like this:

```
In the phone app enter:  ws://192.168.0.161:4443/ws
```

**Copy that address.** Your numbers will be different. Leave this window open. Closing it stops the server.

---

## Step 3: Connect the phone and move

1. Open the app on the phone. In the box, type the address the server printed, then tap **Connect**. The server window shows `Phone connected.`
2. Tap **Start tracking**. Slowly move the phone around, with its **back camera pointing at a bright surface with some pattern** (a rug, a bookshelf, a table with things on it). Wait until it says **Ready**.
3. **Calibrate.** Stand behind the robot, point the phone's back camera towards the front of the robot, and tap **Calibrate**. Now "forward" for the phone is "forward" for the robot.
4. **Hold your thumb on the pad to move.**
   - Left half of the pad = slow and precise.
   - Right half = normal speed.
   - While holding, slide your thumb up or down to open or close the gripper.
   - **Let go to stop.**

Each time you press the pad, the arm starts from where it is, so it never jumps.

Want to look around first? Tap **Preview the controls** on the first screen. It shows the controls without a server.

---

## Using the real arm

**Read this part carefully. The real arm moves for real.**

Before you start:

- Keep one hand near the arm's **power supply** so you can switch it off.
- **Hold or support the arm when you stop the server.** When the server stops, the arm's motors turn off and the arm goes limp.
- Move slowly the first time.
- If the phone's track is lost, the arm stops. This is normal.

Do this once, on a computer connected to the internet:

**Windows**
```
emberarm.bat setup
```
**Ubuntu**
```bash
./emberarm.sh setup
```
(This one installs LeRobot, which is large and takes a while. If this step fails, simulation still works.)

Then calibrate the arm once. The program will ask you to move each joint through its full range:

```
emberarm.bat calibrate          (Windows)
./emberarm.sh calibrate         (Ubuntu)
```

Then start in live mode:

```
emberarm.bat start --live       (Windows)
./emberarm.sh start --live      (Ubuntu)
```

Notes:

- The program finds the arm's USB port by itself. If you have more than one USB device plugged in, tell it which one: `--arm-port COM3` on Windows or `--arm-port /dev/ttyACM0` on Ubuntu.
- If you gave the arm a different name when calibrating, add `--id YOUR_NAME`.
- If the wrist twists the wrong way, add `--roll-sign -1`. If the gripper opens when it should close, add `--invert-gripper`.
- On Ubuntu, if it says "permission denied" on the USB port, run `sudo usermod -aG dialout $USER`, then log out and in again.

The first time, run `emberarm.bat start` (or `./emberarm.sh start`) with no extra words. That is a **dry run**: the phone connects and the server prints what it would do, but nothing moves.

---

## Safety, in short

- The arm only moves while you hold the pad **and** tracking says Ready.
- Letting go, losing Wi-Fi for 3 seconds, or closing the app stops new commands.
- Speed is limited, and the arm cannot go outside its allowed range.
- This is a lab tool and not a certified safety system. Stay close, go slow, and keep the power switch within reach.

---

## If something goes wrong

| Problem | What to try |
| --- | --- |
| The app cannot connect | Check that the server window is still open, that the phone and computer are on the **same Wi-Fi**, and that the address is typed exactly as printed. Office or guest Wi-Fi often blocks devices from seeing each other. Use a home router or a mobile hotspot instead. On Windows, allow Python through the firewall. |
| The address changed | The computer's address can change when you reconnect to Wi-Fi. Stop the server, start it again, and copy the new address. |
| "Tracking lost" or stuck on "Initializing" | Point the back camera at a bright, patterned surface. Move slowly. Plain white walls and dark rooms do not work. |
| The numbers on screen look wild | Move the phone slowly until it says Ready again. Then tap **Calibrate** again. |
| The movement is shaky | The server already smooths the phone's movement. Hold the phone with both hands and move steadily. To compare, turn smoothing off: Windows `set EMBERARM_SMOOTH=0` and Ubuntu `EMBERARM_SMOOTH=0 ./emberarm.sh start --sim`. |
| The arm goes the wrong direction | After tracking was lost, tap **Calibrate** again. For the wrist or gripper, see `--roll-sign` and `--invert-gripper` above. |
| The server says "Phone went silent" | The phone stopped sending for 3 seconds (screen locked, app in the background, or Wi-Fi dropped). Open the app and tap Connect again. Keep the screen on. |
| "MISSING lerobot" or "MISSING opencv" in the server window | Normal for the simulation. You only need LeRobot for the real arm. |
| `emberarm.bat` is not recognised (Windows) | You are not in the `server` folder. Open the `server` folder, then type `cmd` in its address bar. |
| `python3: command not found` (Ubuntu) | Run `sudo apt install -y python3 python3-venv python3-pip`. |

To check that the server's maths is working, without a phone or arm, run `emberarm.bat selftest` (Windows) or `./emberarm.sh selftest` (Ubuntu). It should end with "URDF OK".

---

## Stopping

- Let go of the pad.
- In the server window, press **Ctrl + C**. (With a real arm, support the arm first. It goes limp.)

---

## For developers only: rebuilding the app

You do **not** need this to use the app. Use it only if you change the code in `app-source/`.

You need Node.js 22 or newer, JDK 17, and the Android SDK. Then:

```bash
cd app-source
./build-apk.sh
```

This builds a new `EmberArm-Final.apk`. If a phone is plugged in with USB debugging on, it installs it too. The script is written for Mac and Linux. On Windows, use WSL or ask Deepak to build it.

Built by Deepak.
