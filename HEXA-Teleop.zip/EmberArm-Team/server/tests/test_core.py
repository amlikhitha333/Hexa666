import asyncio, json, sys, tempfile, unittest
from pathlib import Path
from types import SimpleNamespace

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import numpy as np

from emberarm import ports, server
from emberarm.kinematics import SO101Kinematics
from emberarm.recorder import EpisodeRecorder
from emberarm.robot import SimRobot
from emberarm.teleop import PhoneTeleop, validate_pose

URDF = Path(__file__).resolve().parent.parent / "so101_new_calib.urdf"
ARGS = SimpleNamespace(scale=1.0, max_speed=45.0, roll_sign=1.0, invert_gripper=False, task="t")


def pose(x=0.0, y=0.0, z=0.0, q=(0, 0, 0, 1)):
    return {"position": {"x": x, "y": y, "z": z}, "rotation": dict(zip("xyzw", q))}


class FakeWS:
    def __init__(self, msgs): self.msgs, self.sent, self.closed = msgs, [], False
    async def send(self, s): self.sent.append(json.loads(s))
    async def close(self): self.closed = True
    def __aiter__(self): return self._gen()
    async def _gen(self):
        for m in self.msgs:
            yield json.dumps(m)


class Tests(unittest.TestCase):
    def setUp(self): self.kin = SO101Kinematics(URDF)

    def test_ports_macos_dedupe_and_windows(self):
        self.assertEqual(ports.dedupe_macos(["/dev/cu.usbmodem1", "/dev/tty.usbmodem1"]), ["/dev/tty.usbmodem1"])
        self.assertTrue(ports._looks_like_usb_serial("COM3", 0x1A86, 0x55D3))
        self.assertTrue(ports._looks_like_usb_serial("/dev/ttyACM0", None, None))
        self.assertFalse(ports._looks_like_usb_serial("/dev/ttyS0", None, None))
        self.assertFalse(ports._looks_like_usb_serial("COM1", None, None))  # built-in port, no USB ids

    def test_pose_validation(self):
        validate_pose(pose())
        for bad in ({}, pose(x=float("nan")), pose(x=1e6)):
            with self.assertRaises(ValueError): validate_pose(bad)

    def test_control_requires_calibration_then_moves_and_releases(self):
        sim = SimRobot(); t = PhoneTeleop(self.kin, sim)
        with self.assertRaises(ValueError): t.control(pose(), False, None)
        t.calibrate(pose(q=(0, 0, 0, 1)))  # camera looks down -Z: horizontal, OK
        a0 = t.control(pose(), False, None)
        for i in range(1, 30): a = t.control(pose(z=-0.002 * i), False, None)  # forward
        self.assertTrue(t.engaged)
        self.assertNotEqual(a0, a)
        t.release(); self.assertFalse(t.engaged)

    def test_speed_cap(self):
        sim = SimRobot(); t = PhoneTeleop(self.kin, sim, max_speed=10.0)
        t.calibrate(pose()); t.control(pose(), False, None)
        before = t.q_cmd.copy()
        t.control(pose(z=-0.5), False, None)  # huge jump
        self.assertLess(np.degrees(np.abs(t.q_cmd - before)).max(), 10.0 * 0.1 + 1e-6)

    def test_host_protocol_and_disconnect_releases(self):
        host = server.Host(self.kin, SimRobot(), ARGS)
        ws = FakeWS([{"type": "hello"}, {"type": "discover"}, {"type": "control", "deadman": True, "pose": pose()},
                     {"type": "calibrate", "pose": pose()}, {"type": "control", "deadman": True, "pose": pose(), "fine": False, "gripper": None},
                     {"type": "control", "deadman": True, "pose": {"bad": 1}}, {"type": "record", "action": "start"}])
        asyncio.run(host.handler(ws))
        kinds = [m["type"] for m in ws.sent]
        self.assertEqual(kinds[:2], ["ready", "hardware"])
        self.assertEqual(ws.sent[2]["type"], "error")      # control before calibrate
        self.assertIn("state", kinds)
        self.assertEqual(kinds.count("error"), 3)          # + malformed pose + recording-off
        self.assertFalse(host.teleop.engaged)
        self.assertIsNone(host.client)

    def test_second_phone_rejected(self):
        host = server.Host(self.kin, SimRobot(), ARGS); host.client = object()
        ws = FakeWS([]); asyncio.run(host.handler(ws))
        self.assertEqual(ws.sent[0]["type"], "error"); self.assertTrue(ws.closed)

    def test_recording_roundtrip_npz_fallback(self):
        with tempfile.TemporaryDirectory() as d:
            rec = EpisodeRecorder(Path(d) / "ds", "local/x", 30, force_fallback=True)
            sim = SimRobot(); t = PhoneTeleop(self.kin, sim)
            rec.start("pick")
            for _ in range(10): rec.add(sim.get_observation(), t.current_action())
            self.assertEqual(rec.stop(), 10)
            rec.start("pick"); rec.add(sim.get_observation(), t.current_action())
            self.assertEqual(rec.stop(save=False), 0)
            self.assertEqual(rec.episodes, 1)
            data = np.load(Path(d) / "ds" / "episode_000000.npz")
            self.assertEqual(data["state"].shape, (10, 6)); self.assertEqual(data["action"].shape, (10, 6))

    def test_recording_falls_back_when_lerobot_missing(self):
        with tempfile.TemporaryDirectory() as d:
            rec = EpisodeRecorder(Path(d) / "ds", "local/x", 30)
            try:
                import lerobot  # noqa
            except ImportError:
                self.assertEqual(rec.backend.kind, "npz-fallback"); self.assertIsNotNone(rec.warning)

    def test_host_record_commands(self):
        with tempfile.TemporaryDirectory() as d:
            rec = EpisodeRecorder(Path(d) / "ds", "local/x", 30, force_fallback=True)
            host = server.Host(self.kin, SimRobot(), ARGS, rec)
            self.assertTrue(host.record_command("start")["active"])
            rec.add(SimRobot().get_observation(), host.teleop.current_action())
            s = host.record_command("stop"); self.assertEqual((s["active"], s["episodes"]), (False, 1))


if __name__ == "__main__":
    unittest.main()
