"""Serial-port and camera discovery that works on Windows (COMx), macOS and Linux/Jetson."""
from __future__ import annotations

import re
import sys

# USB-serial chips found on SO-101 / Feetech controller boards (and common clones).
KNOWN_VID_PID = {(0x1A86, 0x55D3), (0x1A86, 0x7523), (0x10C4, 0xEA60), (0x0403, 0x6001), (0x0403, 0x6014)}
NAME_HINTS = ("usbmodem", "usbserial", "ttyacm", "ttyusb", "wchusbserial")
COM_RE = re.compile(r"^com\d+$", re.IGNORECASE)


def _looks_like_usb_serial(device: str, vid, pid) -> bool:
    d = device.lower()
    if vid is not None and pid is not None and (vid, pid) in KNOWN_VID_PID:
        return True
    return any(h in d for h in NAME_HINTS) or (COM_RE.match(device) is not None and vid is not None)


def dedupe_macos(devices: list[str]) -> list[str]:
    """macOS lists each adapter twice (/dev/cu.* and /dev/tty.*). LeRobot uses tty.*, keep one."""
    out = []
    for d in devices:
        if d.startswith("/dev/cu.") and d.replace("/dev/cu.", "/dev/tty.", 1) in devices:
            continue
        out.append(d)
    return out


def list_serial_candidates() -> list[dict]:
    """Return [{device, description, vid, pid}] for plausible arm controllers."""
    try:
        from serial.tools import list_ports
    except ImportError:
        return []
    found = []
    for p in list_ports.comports():
        if _looks_like_usb_serial(p.device, p.vid, p.pid):
            found.append({"device": p.device, "description": p.description or "", "vid": p.vid, "pid": p.pid})
    keep = set(dedupe_macos([f["device"] for f in found]))
    found = [f for f in found if f["device"] in keep]
    return sorted(found, key=lambda f: f["device"])


def pick_arm_port(requested: str | None = None) -> str:
    """Use --arm-port if given, else the single detected candidate, else raise with advice."""
    if requested:
        return requested
    candidates = list_serial_candidates()
    if len(candidates) == 1:
        return candidates[0]["device"]
    if not candidates:
        hint = {
            "win32": "Check Device Manager > Ports (COM & LPT). If nothing appears, install the CH340/CP210x driver.",
            "darwin": "Plug in the arm's USB cable and power supply.",
        }.get(sys.platform, "Plug in the arm's USB cable and power supply. On Linux you may need: sudo usermod -aG dialout $USER (then log out and in).")
        raise RuntimeError("No arm found. " + hint + " Or pass --arm-port explicitly.")
    lines = "\n  ".join(f"{c['device']}  ({c['description']})" for c in candidates)
    raise RuntimeError("More than one USB serial device found. Re-run with --arm-port <one of>:\n  " + lines)


def list_cameras(max_index: int = 5) -> list[dict]:
    """Probe OpenCV camera indexes. Optional: returns [] when OpenCV is not installed."""
    try:
        import cv2
    except ImportError:
        return []
    cams = []
    for i in range(max_index):
        cap = cv2.VideoCapture(i)
        try:
            if cap.isOpened():
                ok, frame = cap.read()
                if ok:
                    cams.append({"index": i, "height": int(frame.shape[0]), "width": int(frame.shape[1])})
        finally:
            cap.release()
    return cams


def discover(include_cameras: bool = False) -> dict:
    candidates = list_serial_candidates()
    return {
        "platform": sys.platform,
        "arm_candidates": [c["device"] for c in candidates],
        "arm_details": candidates,
        "arm_port": candidates[0]["device"] if len(candidates) == 1 else None,
        "cameras": list_cameras() if include_cameras else [],
    }
