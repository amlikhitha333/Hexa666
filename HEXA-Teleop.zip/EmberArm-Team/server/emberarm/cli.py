"""emberarm command line: setup | doctor | discover | calibrate | selftest | start | record"""
from __future__ import annotations

import argparse
import asyncio
import json
import platform
import shutil
import subprocess
import sys
from pathlib import Path

import numpy as np

from . import __version__, config, ports
from .kinematics import SEED_DEG, SO101Kinematics

SERVER_DIR = Path(__file__).resolve().parent.parent
URDF_DEFAULT = SERVER_DIR / "so101_new_calib.urdf"


def have(module: str) -> bool:
    try:
        __import__(module)
        return True
    except ImportError:
        return False


# ----------------------------------------------------------------------------- commands
def cmd_selftest(args) -> int:
    kin = SO101Kinematics(args.urdf)
    rng = np.random.default_rng(0)
    worst = 0.0
    for _ in range(25):
        q = np.radians(SEED_DEG + rng.uniform(-15, 15, 5))
        tip, pitch = kin.fk(q)
        _, err = kin.ik(tip + rng.uniform(-0.03, 0.03, 3), pitch, q)
        worst = max(worst, err)
    tip, _ = kin.fk(np.radians(SEED_DEG))
    print(f"URDF OK. Seed pose tip (x fwd, y left, z up) = {np.round(tip, 3)} m")
    print(f"IK worst reach error over 25 random 3 cm moves: {worst * 1000:.2f} mm")
    return 0 if worst < 0.002 else 1


def cmd_doctor(_args) -> int:
    print(f"EmberArm host {__version__} | Python {platform.python_version()} | {platform.system()} {platform.machine()}")
    rows = [("numpy", have("numpy")), ("websockets", have("websockets")), ("pyserial", have("serial")),
            ("lerobot", have("lerobot")), ("opencv (cameras)", have("cv2"))]
    for name, ok in rows:
        print(f"  {'OK     ' if ok else 'MISSING'} {name}")
    print(f"  {'OK     ' if URDF_DEFAULT.exists() else 'MISSING'} URDF ({URDF_DEFAULT.name})")
    print(f"  {'OK     ' if shutil.which('lerobot-calibrate') else 'MISSING'} lerobot-calibrate command")
    info = ports.discover()
    print("  Arm candidates:", info["arm_candidates"] or "none found")
    if sys.version_info < (3, 10):
        print("  Python 3.10 or newer is required.")
    missing = [n for n, ok in rows[:3] if not ok]
    return 1 if missing else 0


def cmd_setup(args) -> int:
    pip = [sys.executable, "-m", "pip", "install"]
    print("Installing EmberArm host requirements ...")
    code = subprocess.call(pip + ["-r", str(SERVER_DIR / "requirements.txt")])
    if code:
        return code
    if not args.no_lerobot:
        print('Installing LeRobot with Feetech support (large; skip with --no-lerobot) ...')
        code = subprocess.call(pip + ["lerobot[feetech]"])
        if code:
            print("LeRobot install failed. Simulation and dry run still work; see README for LeRobot's own install guide.")
    cfg = config.load()
    config.save(cfg)
    print(f"Config: {config.CONFIG_PATH}")
    return cmd_doctor(args)


def cmd_discover(args) -> int:
    print(json.dumps(ports.discover(include_cameras=args.cameras), indent=2))
    return 0


def cmd_calibrate(args) -> int:
    cfg = config.load()
    exe = shutil.which("lerobot-calibrate")
    if not exe:
        print('LeRobot is not installed. Run:  emberarm setup')
        return 1
    try:
        port = ports.pick_arm_port(args.arm_port or cfg["arm_port"])
    except RuntimeError as error:
        print(error)
        return 1
    rid = args.id or cfg["robot_id"]
    print(f"Calibrating follower '{rid}' on {port}. Follow LeRobot's prompts and move each joint through its range.")
    return subprocess.call([exe, "--robot.type=so101_follower", f"--robot.port={port}", f"--robot.id={rid}"])


def _parse_cameras(items: list[str] | None, cfg_cams: dict) -> dict[str, int]:
    cams = dict(cfg_cams)
    for item in items or []:
        name, _, idx = item.partition("=")
        cams[name] = int(idx)
    return cams


def cmd_run(args, record: bool) -> int:
    from . import server
    from .recorder import EpisodeRecorder
    from .robot import LeRobotRobot, SimRobot

    if not args.urdf.exists():
        print(f"URDF not found at {args.urdf}")
        return 1
    kin = SO101Kinematics(args.urdf)
    mode = "live" if args.live else ("sim" if (args.sim or record) else "dry")
    if record and mode == "dry":
        mode = "sim"
        print("No --live given: recording against the simulator.")
    robot, port, cams = None, None, _parse_cameras(args.camera, args.cfg["cameras"])
    if mode == "live":
        try:
            port = ports.pick_arm_port(args.arm_port or args.cfg["arm_port"])
            print(f"Connecting to arm on {port} ...")
            robot = LeRobotRobot(port, args.id, max_step_deg=5.0, cameras=cams)
        except RuntimeError as error:
            print(error)
            return 1
        print("Arm connected. Keep your hand clear. Hold the pad on the phone to move.")
    elif mode == "sim":
        robot = SimRobot()
        print("SIMULATION: no hardware used.")
    else:
        print("DRY RUN: the arm will not move. Use --sim to simulate, --live to move the arm.")

    recorder = None
    if record:
        sizes = {n: (640, 480) for n in cams} if mode == "live" else {}
        recorder = EpisodeRecorder(Path(args.dataset_dir), args.repo_id, args.fps, sizes, force_fallback=args.fallback_format)
        if recorder.warning:
            print("WARNING:", recorder.warning)
        print(f"Recording to {args.dataset_dir} ({recorder.backend.kind}) at {args.fps} fps. Task: '{args.task}'")

    host = server.Host(kin, robot, args, recorder, port)
    try:
        asyncio.run(server.serve(host, args.ws_port))
    except KeyboardInterrupt:
        pass
    finally:
        if recorder is not None:
            recorder.close()
        if robot is not None:
            print("Disconnecting. Note: the arm goes limp when torque turns off - support it.")
            robot.disconnect()
    return 0


# ----------------------------------------------------------------------------- parser
def build_parser(cfg: dict) -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="emberarm", description="EmberArm host: Android phone as virtual leader for an SO-101 follower.")
    p.add_argument("--version", action="version", version=__version__)
    sub = p.add_subparsers(dest="command", required=True)

    s = sub.add_parser("setup", help="install requirements (+ LeRobot) and check the machine")
    s.add_argument("--no-lerobot", action="store_true")
    sub.add_parser("doctor", help="check dependencies and detected hardware")
    d = sub.add_parser("discover", help="list arm ports (and optionally cameras)")
    d.add_argument("--cameras", action="store_true")
    c = sub.add_parser("calibrate", help="calibrate the follower arm through LeRobot")
    c.add_argument("--arm-port"); c.add_argument("--id")
    t = sub.add_parser("selftest", help="check URDF + IK; no phone or arm needed")
    t.add_argument("--urdf", type=Path, default=URDF_DEFAULT)

    def run_args(sp: argparse.ArgumentParser) -> None:
        sp.add_argument("--live", action="store_true", help="move the real arm")
        sp.add_argument("--sim", action="store_true", help="simulated arm, no hardware")
        sp.add_argument("--urdf", type=Path, default=URDF_DEFAULT)
        sp.add_argument("--arm-port", default=cfg["arm_port"], help="serial port (COM3, /dev/ttyACM0, /dev/tty.usbmodem...); auto-detected if omitted")
        sp.add_argument("--id", default=cfg["robot_id"], help="LeRobot robot id used when calibrating")
        sp.add_argument("--ws-port", type=int, default=cfg["ws_port"])
        sp.add_argument("--scale", type=float, default=cfg["scale"])
        sp.add_argument("--max-speed", type=float, default=cfg["max_speed"], help="joint speed cap, deg/s")
        sp.add_argument("--roll-sign", type=float, default=cfg["roll_sign"])
        sp.add_argument("--invert-gripper", action="store_true", default=cfg["invert_gripper"])
        sp.add_argument("--camera", action="append", metavar="NAME=INDEX", help="e.g. --camera front=0 (live mode, repeatable)")
        sp.add_argument("--task", default=cfg["task"])

    st = sub.add_parser("start", help="run the host (dry run by default)")
    run_args(st)
    r = sub.add_parser("record", help="run the host and record demonstration episodes")
    run_args(r)
    r.add_argument("--dataset-dir", default=cfg["dataset_dir"])
    r.add_argument("--repo-id", default=cfg["repo_id"])
    r.add_argument("--fps", type=int, default=cfg["fps"])
    r.add_argument("--fallback-format", action="store_true", help="write plain NPZ episodes instead of a LeRobotDataset")
    return p


def main(argv: list[str] | None = None) -> None:
    cfg = config.load()
    args = build_parser(cfg).parse_args(argv)
    args.cfg = cfg
    handlers = {"setup": cmd_setup, "doctor": cmd_doctor, "discover": cmd_discover, "calibrate": cmd_calibrate,
                "selftest": cmd_selftest, "start": lambda a: cmd_run(a, False), "record": lambda a: cmd_run(a, True)}
    sys.exit(handlers[args.command](args))
