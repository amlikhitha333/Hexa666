"""WebSocket host: phone messages in, robot commands + dataset frames out."""
from __future__ import annotations

import asyncio
import json
import socket
import sys
import threading
import time

from .teleop import ENGAGE_GAP_S, PhoneTeleop
from . import ports

PROTOCOL = 1
LINK_TIMEOUT_S = 3.0  # phone silent this long while connected -> treat the link as lost


def local_ip() -> str:
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))  # no packet is sent; just picks the outbound interface
        return s.getsockname()[0]
    except OSError:
        return "your-computer-ip"
    finally:
        s.close()


class Host:
    def __init__(self, kin, robot, args, recorder=None, arm_port: str | None = None) -> None:
        self.args, self.robot, self.recorder, self.arm_port = args, robot, recorder, arm_port
        self.teleop = PhoneTeleop(kin, robot, scale=args.scale, max_speed=args.max_speed, roll_sign=args.roll_sign,
                                  invert_gripper=args.invert_gripper)
        self.client = None
        self.last_msg = 0.0
        self._latest_control: dict | None = None
        self._latest_control_at = 0.0
        self._output_period_s = 1.0 / 50.0
        self.mode = "live" if (robot is not None and not getattr(robot, "is_sim", False)) else ("sim" if robot is not None else "dry")

    # ---- protocol (kept compatible with the v7 app)
    def _hardware(self) -> dict:
        info = ports.discover(include_cameras=False)
        return {"type": "hardware", "arm_port": self.arm_port or info["arm_port"], "arm_candidates": info["arm_candidates"],
                "cameras": [], "motor_enabled": self.mode == "live", "mode": self.mode}

    def recording_state(self) -> dict:
        r = self.recorder
        return {"type": "recording", "enabled": r is not None, "active": bool(r and r.active),
                "episodes": r.episodes if r else 0, "frames": r.frames if r else 0}

    def record_command(self, action: str, task: str | None = None) -> dict:
        if self.recorder is None:
            raise ValueError("Recording is off. Start the host with:  emberarm record --sim|--live")
        if action == "start":
            self.recorder.start(task or self.args.task)
        elif action == "stop":
            self.recorder.stop(save=True)
        elif action == "discard":
            self.recorder.stop(save=False)
        else:
            raise ValueError(f"Unknown record action '{action}'.")
        return self.recording_state()

    async def process(self, message: dict) -> dict | None:
        kind = message.get("type")
        if kind == "hello":
            return {"type": "ready", "protocol": PROTOCOL, "mode": self.mode}
        if kind == "discover":
            return self._hardware()
        if kind == "calibrate":
            self.teleop.calibrate(message["pose"])
            return {"type": "calibrated"}
        if kind == "control":
            if message.get("deadman") is not True:
                self._latest_control = None
                self._latest_control_at = 0.0
                self.teleop.release()
                return None
            # Keep only the newest frame. Waiting for motor I/O here lets stale
            # poses pile up and is the main cause of jerky catch-up movement.
            self._latest_control = message
            self._latest_control_at = time.monotonic()
            return {"type": "state", "gripper": round(self.teleop.grip_for_app(), 1)}
        if kind == "record":
            return self.record_command(str(message.get("action", "")), message.get("task"))
        return None

    @staticmethod
    async def _safe_send(websocket, payload: dict) -> bool:
        """Send to the phone; return False (instead of raising) if it already hung up."""
        from websockets.exceptions import ConnectionClosed  # lazy: serve() reports a friendly error if missing
        try:
            await websocket.send(json.dumps(payload))
            return True
        except ConnectionClosed:
            return False

    async def handler(self, websocket) -> None:
        if self.client is not None:
            await self._safe_send(websocket, {"type": "error", "message": "Another phone is already connected to this host."})
            await websocket.close()
            return
        self.client = websocket
        self.last_msg = time.monotonic()
        print("Phone connected.")
        watchdog = asyncio.create_task(self._watchdog(websocket))
        control_loop = asyncio.create_task(self._control_loop())
        try:
            async for raw in websocket:
                self.last_msg = time.monotonic()
                try:
                    reply = await self.process(json.loads(raw))
                    if reply is not None:
                        await self._safe_send(websocket, reply)
                except (KeyError, TypeError, ValueError, json.JSONDecodeError) as error:
                    await self._safe_send(websocket, {"type": "error", "message": str(error)})
                except Exception as error:  # robot/serial failure: stop moving, tell the phone, keep serving
                    self.teleop.release()
                    print(f"Robot error: {error}", file=sys.stderr)
                    await self._safe_send(websocket, {"type": "error", "message": f"Robot error: {error}"})
        finally:
            watchdog.cancel()
            control_loop.cancel()
            self._latest_control = None
            self._latest_control_at = 0.0
            self.teleop.release()
            self.client = None
            print("Phone disconnected. Arm holds its last position.")

    async def _watchdog(self, websocket) -> None:
        while True:
            await asyncio.sleep(0.1)
            now = time.monotonic()
            t = self.teleop
            if t.engaged and t.last_ctrl is not None and now - t.last_ctrl > ENGAGE_GAP_S:
                t.release()  # pad released
            if now - self.last_msg > LINK_TIMEOUT_S:
                t.release()
                print("Phone went silent; closing the link.")
                await websocket.close()
                return

    async def _control_loop(self) -> None:
        """Output robot targets at a stable 50 Hz, independent of Wi-Fi timing."""
        while True:
            await asyncio.sleep(self._output_period_s)
            message = self._latest_control
            if message is None:
                continue
            if time.monotonic() - self._latest_control_at > ENGAGE_GAP_S:
                self._latest_control = None
                self.teleop.release()
                continue
            grip = message.get("gripper")
            try:
                await asyncio.to_thread(self.teleop.control, message["pose"], bool(message.get("fine")), None if grip is None else float(grip))
            except Exception as error:
                if "Calibrate first" in str(error):
                    try:
                        self.teleop.calibrate(message["pose"])
                        print("Auto-calibrated from the current phone pose.")
                    except Exception as e2:
                        print(f"Auto-calibrate failed: {e2}", file=sys.stderr)
                    continue
                self.teleop.release()
                print(f"Control error: {error}", file=sys.stderr)

    # ---- recording loop (fixed fps, independent of how fast the phone sends)
    async def record_loop(self) -> None:
        r = self.recorder
        period = 1.0 / r.fps
        nxt = time.monotonic()
        while True:
            nxt += period
            if r.active:
                try:
                    obs = await asyncio.to_thread(self.robot.get_observation)
                    r.add(obs, self.teleop.current_action())
                except Exception as error:
                    print(f"Recording error: {error}", file=sys.stderr)
            await asyncio.sleep(max(0.0, nxt - time.monotonic()))

    # ---- terminal commands while running
    def start_console(self, loop: asyncio.AbstractEventLoop, stop: asyncio.Future) -> None:
        def run() -> None:
            print("Terminal: [r] start/stop+save episode   [d] discard episode   [q] quit")
            for line in sys.stdin:
                cmd = line.strip().lower()
                try:
                    if cmd == "r" and self.recorder:
                        s = self.record_command("stop" if self.recorder.active else "start")
                        print(f"Recording {'ON' if s['active'] else 'OFF'}  episodes saved: {s['episodes']}")
                    elif cmd == "d" and self.recorder:
                        self.record_command("discard"); print("Episode discarded.")
                    elif cmd == "q":
                        loop.call_soon_threadsafe(lambda: stop.done() or stop.set_result(None)); return
                except ValueError as error:
                    print(error)

        threading.Thread(target=run, daemon=True).start()


async def serve(host: Host, ws_port: int) -> None:
    try:
        import websockets
    except ImportError:
        sys.exit("The 'websockets' package is missing. Run:  emberarm setup")
    loop = asyncio.get_running_loop()
    stop = loop.create_future()
    async with websockets.serve(host.handler, "0.0.0.0", ws_port, ping_interval=5, ping_timeout=5):
        print(f"Mode: {host.mode.upper()}")
        print(f"In the phone app enter:  ws://{local_ip()}:{ws_port}/ws")
        try:
            from .viewer import start_viewer
            start_viewer(host)
        except Exception as error:
            print(f"Arm viewer unavailable: {error}")
        if host.recorder is not None:
            host.start_console(loop, stop)
            loop.create_task(host.record_loop())
        await stop
