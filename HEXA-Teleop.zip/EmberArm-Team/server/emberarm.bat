@echo off
REM Windows launcher. First run creates a virtualenv; then:  emberarm.bat start --sim
cd /d "%~dp0"
if not exist .venv (
  py -3 -m venv .venv || python -m venv .venv
  .venv\Scripts\python -m pip install --upgrade pip -q
  .venv\Scripts\python -m pip install -r requirements.txt
)
.venv\Scripts\python -m emberarm %*
