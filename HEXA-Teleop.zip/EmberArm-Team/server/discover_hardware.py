"""Print SO-101 serial-port candidates (and cameras with --cameras)."""
import sys

from emberarm.cli import main

if __name__ == "__main__":
    main(["discover"] + sys.argv[1:])
