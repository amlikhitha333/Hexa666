"""Backward-compatible entry point (v7 used: python3 teleop_server.py [--live] [--selftest]).
Prefer:  python -m emberarm <command>   (see README)."""
import sys

from emberarm.cli import main

if __name__ == "__main__":
    argv = sys.argv[1:]
    if "--selftest" in argv:
        main(["selftest"])
    main(["start"] + argv)
